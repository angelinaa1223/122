
const img = [];
function TextSetable(){
    let a=Math.floor(Math.random() * (10 - 1)); 
    document.getElementById('myImg').src=img[a];  
}